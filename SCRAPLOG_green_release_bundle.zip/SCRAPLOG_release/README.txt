SCRAPLOG GREEN V2 — deployment bundle

Files:
- index.html: current green prototype (local browser storage; cloud not connected in the UI)
- manifest.webmanifest, icon.svg, sw.js: PWA installability/offline shell files
- supabase_schema.sql: separate cloud schema foundation with company membership and RLS

To publish on GitHub Pages:
1. In your GitHub repository, open index.html and choose the pencil/Edit button.
2. Replace the contents with this bundle's index.html content (or upload/replace the file).
3. Commit changes to main.
4. In Settings > Pages, ensure deploy source is main branch and root (/).
5. Wait for deployment, then open https://emilduros.github.io/scraplog/ .
For PWA files, upload manifest.webmanifest, sw.js, and icon.svg to the repository root as well.

Important: this bundle is not production SaaS. UI data is stored in localStorage. The SQL schema is a foundation only and has not been executed or security-audited in your Supabase project. Do not use production/customer data until cloud integration, auth flow, company onboarding, policies and testing are complete.
