-- SCRAPLOG cloud foundation (run in Supabase SQL Editor)
create extension if not exists pgcrypto;

create table if not exists public.scraplog_companies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  cvr text,
  owner_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
create table if not exists public.scraplog_members (
  company_id uuid not null references public.scraplog_companies(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'employee' check (role in ('owner','admin','employee')),
  created_at timestamptz not null default now(),
  primary key(company_id,user_id)
);
create or replace function public.scraplog_is_member(company uuid)
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from scraplog_members m where m.company_id=company and m.user_id=auth.uid()) $$;
create or replace function public.scraplog_is_admin(company uuid)
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from scraplog_members m where m.company_id=company and m.user_id=auth.uid() and m.role in ('owner','admin')) $$;
create or replace function public.scraplog_add_owner_member()
returns trigger language plpgsql security definer set search_path=public
as $$ begin insert into public.scraplog_members(company_id,user_id,role) values(new.id,new.owner_id,'owner'); return new; end $$;
drop trigger if exists scraplog_company_owner_membership on public.scraplog_companies;
create trigger scraplog_company_owner_membership after insert on public.scraplog_companies for each row execute function public.scraplog_add_owner_member();

create table if not exists public.scraplog_projects (
 id uuid primary key default gen_random_uuid(), company_id uuid not null references public.scraplog_companies(id) on delete cascade,
 name text not null, project_no text, customer text, address text, status text not null default 'Active', start_date date, end_date date, notes text,
 created_by uuid default auth.uid(), created_at timestamptz not null default now()
);
create table if not exists public.scraplog_scrap (
 id uuid primary key default gen_random_uuid(), company_id uuid not null references public.scraplog_companies(id) on delete cascade,
 project_id uuid not null references public.scraplog_projects(id) on delete cascade, date date, material text not null,
 weight_kg numeric not null default 0 check(weight_kg>=0), price_per_kg numeric not null default 0 check(price_per_kg>=0), total numeric not null default 0,
 buyer text, voucher_no text, notes text, created_by uuid default auth.uid(), created_at timestamptz not null default now()
);
create table if not exists public.scraplog_waste (
 id uuid primary key default gen_random_uuid(), company_id uuid not null references public.scraplog_companies(id) on delete cascade,
 project_id uuid not null references public.scraplog_projects(id) on delete cascade, date date, fraction text not null,
 weight_kg numeric not null default 0 check(weight_kg>=0), cost numeric not null default 0 check(cost>=0), receiver text, voucher_no text, notes text,
 created_by uuid default auth.uid(), created_at timestamptz not null default now()
);
create table if not exists public.scraplog_expenses (
 id uuid primary key default gen_random_uuid(), company_id uuid not null references public.scraplog_companies(id) on delete cascade,
 project_id uuid not null references public.scraplog_projects(id) on delete cascade, date date, category text not null,
 description text, amount numeric not null default 0 check(amount>=0), supplier text, voucher_no text, notes text,
 created_by uuid default auth.uid(), created_at timestamptz not null default now()
);

alter table public.scraplog_companies enable row level security;
alter table public.scraplog_members enable row level security;
alter table public.scraplog_projects enable row level security;
alter table public.scraplog_scrap enable row level security;
alter table public.scraplog_waste enable row level security;
alter table public.scraplog_expenses enable row level security;

drop policy if exists companies_read_member on public.scraplog_companies;
create policy companies_read_member on public.scraplog_companies for select to authenticated using (public.scraplog_is_member(id));
drop policy if exists companies_insert_owner on public.scraplog_companies;
create policy companies_insert_owner on public.scraplog_companies for insert to authenticated with check (owner_id=auth.uid());
drop policy if exists companies_update_admin on public.scraplog_companies;
create policy companies_update_admin on public.scraplog_companies for update to authenticated using (public.scraplog_is_admin(id)) with check (public.scraplog_is_admin(id));
drop policy if exists members_read_self_or_admin on public.scraplog_members;
create policy members_read_self_or_admin on public.scraplog_members for select to authenticated using (user_id=auth.uid() or public.scraplog_is_admin(company_id));
drop policy if exists members_admin_insert on public.scraplog_members;
create policy members_admin_insert on public.scraplog_members for insert to authenticated with check (public.scraplog_is_admin(company_id));
drop policy if exists members_admin_delete on public.scraplog_members;
create policy members_admin_delete on public.scraplog_members for delete to authenticated using (public.scraplog_is_admin(company_id));

-- Shared company-membership policies for operational tables.
do $$ declare t text; begin
 foreach t in array['scraplog_projects','scraplog_scrap','scraplog_waste','scraplog_expenses'] loop
  execute format('drop policy if exists %I_member_access on public.%I',t,t);
  execute format('create policy %I_member_access on public.%I for all to authenticated using (public.scraplog_is_member(company_id)) with check (public.scraplog_is_member(company_id))',t,t);
 end loop;
end $$;
